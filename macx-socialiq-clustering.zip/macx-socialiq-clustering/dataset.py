import h5py
from tqdm import tqdm
import random

import numpy as np
import torch
from torch.utils.data import Dataset

import folds

from sklearn.cluster import k_means
from collections import Counter
from collections import defaultdict
import warnings
import torch.nn.functional as F

class SocialIQ(Dataset):

    def __init__(self, root, phase, mods, a4=False):
        self.root = root
        
        if phase != "train":
            incorrect_indices = []
            with open(self.root + "/incorrect_indices.txt", "r") as f:
                lines = f.read().splitlines()
                #print(len(lines))
                for line in lines:
                    #print(line.split())
                    incorrect_indices.append([int(i) for i in line.split()])
        #print(incorrect_indices)
        self.h_qa = None
        if not a4:
            self.h_qa = h5py.File(self.root + '/socialiq/SOCIAL-IQ_QA_BERT_LASTLAYER_BINARY_CHOICE.csd', 'r')
        else:
            self.h_qa = h5py.File(self.root + '/socialiq/SOCIAL-IQ_QA_BERT_MULTIPLE_CHOICE.csd', 'r')

        self.h_v = None
        if 'v' in mods:
            self.h_v = h5py.File(self.root + '/socialiq/SOCIAL_IQ_DENSENET161_1FPS.csd', 'r')

        self.h_t = None
        if 't' in mods:
            self.h_t = h5py.File(self.root + '/socialiq/SOCIAL_IQ_TRANSCRIPT_RAW_CHUNKS_BERT.csd', 'r')

        self.h_ac = None
        if 'ac' in mods:
            self.h_ac = h5py.File(self.root + '/socialiq/SOCIAL_IQ_COVAREP.csd', 'r')

        if phase == 'train':
            fold = folds.standard_train_fold
        else:
            fold = folds.standard_valid_fold
            #fold = ['B6PpxrnttDg', 'pawEXwLjTlo', 'bgczomH1kLk', 'jh5PklItWjA', 'JRYjFh_hHBs', 'GbYGoWvJpwI', 'IbkyL0pDtEc']

        self.samples = []
        n = 0
        for sid in tqdm(fold):

            feats = ()

            if 'ac' in mods:
                acfeats = torch.from_numpy(
                    np.nan_to_num(self.h_ac['SOCIAL_IQ_COVAREP']['data'][sid]['features'][()], posinf=1e3, neginf=-1e3))
                ac_1ps = []
                #prev_ps = acfeats.shape[0] // 60
                prev_ps = 100
                for i in range(0, acfeats.shape[0], prev_ps):
                    #ac_1ps.append(acfeats[i:i + prev_ps].mean(0))
                    acfeat = acfeats[i:i+prev_ps]
                    #print(acfeat.shape)
                    if acfeat.shape[0] < 100:
                        acfeat = F.pad(acfeat, (0, 0, 0, 100-acfeat.shape[0]), mode='constant', value=0)
                        #print("Pad: " + str(acfeat.shape))
                    acfeat = acfeat.reshape(10, 740).mean(0)
                    ac_1ps.append(acfeat)
                acfeats = torch.stack(ac_1ps[:60])
                if acfeats.shape[0] < 60:
                    acfeats = F.pad(acfeats, (0, 0, 0, 60-acfeats.shape[0]), mode='constant', value=0)
                acfeats = F.pad(acfeats, (0, 28, 0, 0), mode='constant', value=0)
                #feats = (acfeats,) + feats

            if 'v' in mods:
                visfeats = torch.from_numpy(self.h_v['SOCIAL_IQ_DENSENET161_1FPS']['data'][sid]['features'][()])
                #avgs = []
                #for i in range(0, visfeats.shape[0]):
                    #part1 = torch.mean(visfeats[i, 0:192].reshape(-1, 2), axis=1)
                    #part2 = torch.mean(visfeats[i, 192:].reshape(-1, 3), axis=1)
                    #feat = []
                    #for j in range(0, 384, 2):
                        #feat.append(visfeats[i,j:j+2].mean(0))
                    #for k in range(384, 2208, 3):
                        #feat.append(visfeats[i,k:k+3].mean(0))
                    #avgs.append(torch.cat([part1, part2]))
                #visfeats = torch.stack(avgs)
                part1 = torch.mean(visfeats[:, 0:192].reshape(visfeats.shape[0],-1,2), axis=2)
                #print(visfeats[:, 0:192].reshape(visfeats.shape[0], -1,2).shape)
                #print(part1.shape)
                part2 = torch.mean(visfeats[:, 192:].reshape(visfeats.shape[0],-1,3), axis=2)
                visfeats = torch.cat([part1, part2], axis=1)
                #print(visfeats.shape)
                #feats = (visfeats,) + feats

            if 't' in mods:
                subtitles = torch.from_numpy(
                    self.h_t['SOCIAL_IQ_TRANSCRIPT_RAW_CHUNKS_BERT']['data'][sid]['features'][()]).view(-1, 9216)[:,
                            -768:]
                toks = subtitles.shape[0]
                if toks < 61:
                    subtitles = torch.cat([subtitles, torch.zeros((60 - toks, subtitles.shape[1]))], dim=0)
                else:
                    if not subtitles.any():
                        subtitles = subtitles[:60, :]
                    else:
                        with warnings.catch_warnings():
                            warnings.filterwarnings('error')
                            try:
                                text_centroids, labels, _ = k_means(subtitles, n_clusters=61, init='k-means++')
                                counts = Counter(labels)
                                excluded_cluster = max(list(counts.items()), key=lambda k: k[1])[0]
                                indices = defaultdict(lambda: 0)
                                for i in range(len(labels)):
                                    if labels[i] != excluded_cluster:
                                        indices[labels[i]] += i/counts[labels[i]]
                                        order = sorted(list(indices.items()), key=lambda k: k[1])
                                subtitles = torch.from_numpy(np.array([text_centroids[i[0]] for i in order], dtype='float32'))
                            except:
                                subtitles = torch.from_numpy(np.array(text_centroids[:60, :], dtype='float32'))
                if subtitles.shape[0] != 60:
                    print(sid)
                total_feats = torch.cat((acfeats, visfeats, subtitles), 0)
                one_centroids, labels, _ = k_means(total_feats, n_clusters=60, init='k-means++')
                two_centroids, labels, _ = k_means(one_centroids, n_clusters=30, init='k-means++')
                three_centroids, labels, _ = k_means(two_centroids, n_clusters=15, init='k-means++')
                #feats = (subtitles,) + feats
                feats = (torch.from_numpy(np.array(one_centroids, dtype='float32')),) + feats
                feats = (torch.from_numpy(np.array(two_centroids, dtype='float32')),) + feats
                feats = (torch.from_numpy(np.array(three_centroids,dtype='float32')),) + feats

            if not a4:
                qa_embs = torch.from_numpy(
                    self.h_qa['SOCIAL-IQ_QA_BERT_LASTLAYER_BINARY_CHOICE']['data'][sid]['features'][0])
            else:
                qa_embs = torch.from_numpy(self.h_qa['SOCIAL-IQ_QA_BERT_MULTIPLE_CHOICE']['data'][sid]['features'][0])
            new_questions = []
            for i_q, question in enumerate(qa_embs):
                for i_c, combination in enumerate(question):
                    enum = list(enumerate(combination[1:]))
                    random.shuffle(enum)
                    ini_ind, combi = zip(*enum)
                    label = ini_ind.index(0)
                    new_questions.append((combination[0], *combi, label,) + feats)
            if phase != "train":
                new_questions = [new_questions[j] for j in incorrect_indices[n]]
                n += 1
            self.samples += new_questions

        if self.h_qa is not None:
            self.h_qa.close()
        if self.h_v is not None:
            self.h_v.close()
        if self.h_t is not None:
            self.h_t.close()
        if self.h_ac is not None:
            self.h_ac.close()

    def __getitem__(self, index):
        return self.samples[index]

    def __len__(self):
        return len(self.samples)
